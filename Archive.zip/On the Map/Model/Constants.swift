//
//  Constants.swift
//  On the Map
//
//  Created by ALCALY LO on 3/7/18.
//  Copyright © 2018 ALCALY LO. All rights reserved.
//

import Foundation

struct Constants
{
    struct StudentInformation
    {
        static var lat: Double = 0.0
        static var long: Double = 0.0
        static var location: String = ""
        static var uniqueKey: String = ""
        static var url: String = ""
        static var firstName: String = "First Name"
        static var lastName: String = "Last Name"
        
    }
}
